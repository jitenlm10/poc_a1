# app/plot_boxplots_all.py
# Version: simplified (no grey horizontal dotted lines)
# Produces a clean single figure with 3 side-by-side boxplots and labeled quartiles.

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
OUT_DIR  = Path(__file__).resolve().parents[1] / "report" / "boxplots"
OUT_DIR.mkdir(parents=True, exist_ok=True)

FILES = [
    ("Category & Year",       DATA_DIR / "bench_count_category_years.csv"),
    ("Motivation Keyword",    DATA_DIR / "bench_count_keyword.csv"),
    ("Name",                  DATA_DIR / "bench_lookup_name.csv"),
]

def _load(csv_path: Path):
    df = pd.read_csv(csv_path)
    if "latency_ms" not in df.columns:
        raise ValueError(f"CSV missing 'latency_ms': {csv_path}")
    return df["latency_ms"].astype(float).tolist()

def _tukey(vals):
    q1 = np.percentile(vals, 25)
    q2 = np.percentile(vals, 50)
    q3 = np.percentile(vals, 75)
    iqr = q3 - q1
    lower_lim = q1 - 1.5 * iqr
    upper_lim = q3 + 1.5 * iqr
    lw = min([v for v in vals if v >= lower_lim], default=min(vals))
    uw = max([v for v in vals if v <= upper_lim], default=max(vals))
    return q1, q2, q3, lw, uw

def main():
    labels, datasets = [], []
    for lbl, path in FILES:
        if not path.exists():
            raise FileNotFoundError(f"Missing CSV: {path}. Run grpc_client_bench.py first.")
        labels.append(lbl)
        datasets.append(_load(path))

    fig = plt.figure(figsize=(18, 6))
    ax = plt.gca()

    bp = ax.boxplot(
        datasets,
        positions=[1, 2, 3],
        vert=True,
        showmeans=True,
        whis=1.5
    )

    ax.set_xticks([1, 2, 3])
    ax.set_xticklabels(labels)
    ax.set_ylabel("Delay (W@S)")
    ax.set_title("End-to-End Delay for 100 Runs of Each Query")
    ax.grid(True, axis="y", linestyle="--", alpha=0.0)  # effectively disables gridlines

    def annotate_box(xpos, vals):
        q1, q2, q3, lw, uw = _tukey(vals)
        # Removed dashed guide lines
        ax.text(xpos + 0.18, uw,  f"{uw:.3f} W@S", fontsize=8, va="bottom")
        ax.text(xpos + 0.18, q3,  f"{q3:.3f} W@S", fontsize=8, va="bottom")
        ax.text(xpos - 0.35, q2,  f"{q2:.3f} W@S", fontsize=8, va="center")
        ax.text(xpos - 0.35, q1,  f"{q1:.3f} W@S", fontsize=8, va="top")
        ax.text(xpos - 0.35, lw,  f"{lw:.3f} W@S", fontsize=8, va="top")

    for xpos, vals in zip([1, 2, 3], datasets):
        annotate_box(xpos, vals)

    out_path = OUT_DIR / "latency_boxplots_all_clean.png"
    plt.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    print(f"[plot] saved: {out_path}")

if __name__ == "__main__":
    main()
