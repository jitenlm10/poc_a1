# setup_nobel_redis.py
# Loads Nobel data (2013–2023) as JSON, embeds a vector inside each JSON doc,
# and creates a single RediSearch index ON JSON that includes a VECTOR field.

import json
import hashlib
import requests
# from redis import Redis
from test_redis import rcli

# ---- dataset and schema config ----
nobel_url = "https://api.nobelprize.org/v1/prize.json"
year_lo, year_hi = 2013, 2023

key_prefix = "nobeljson:leaf:"
vec_path   = "$.laureates_vec"   # JSON path where the vector array lives
vec_alias  = "laureates"         # field name exposed to the index as VECTOR
vec_dim    = 32                  # small deterministic dimension for demo

def make_small_vec(text_seed: str, dim: int = vec_dim) -> list[float]:
    """
    Produce a deterministic float list from SHA256 bytes.
    This keeps setup light while still providing a proper VECTOR field.
    """
    digest = hashlib.sha256(text_seed.encode("utf-8")).digest()
    return [(digest[i % len(digest)] / 255.0) * 0.01 for i in range(dim)]

def get_prizes_filtered() -> list[dict]:
    """
    Fetch the Nobel dataset and keep only entries in the target year window.
    """
    resp = requests.get(nobel_url, timeout=45)
    resp.raise_for_status()
    items = resp.json().get("prizes", [])
    keep = []
    for p in items:
        if not (p.get("year") and p.get("category")):
            continue
        yv = int(p["year"])
        if year_lo <= yv <= year_hi:
            keep.append(p)
    return keep

def load_docs_json():
    """
    Create one JSON document per laureate occurrence and store it under key_prefix.
    Each doc contains: year, category, firstname, surname, motivation, laureates_vec.
    """
    # Clear only this namespace for repeatable runs
    for k in rcli.scan_iter(f"{key_prefix}*"):
        rcli.delete(k)

    count_loaded = 0
    with rcli.pipeline(transaction=False) as pipe:
        for prize in get_prizes_filtered():
            yv = int(prize["year"])
            cat = prize["category"]
            for idx, lr in enumerate(prize.get("laureates", []) or []):
                fn = lr.get("firstname", "")
                ln = lr.get("surname", "")
                mt = (lr.get("motivation", "") or "").strip('"')

                doc_key = f"{key_prefix}{yv}:{cat}:{lr.get('id','x')}:{idx}"
                doc_obj = {
                    "year": yv,
                    "category": cat,
                    "firstname": fn,
                    "surname": ln,
                    "motivation": mt,
                }

                # Embed a small numeric vector inside JSON (as an array of floats)
                seed = f"{fn}|{ln}|{mt}|{cat}|{yv}"
                doc_obj["laureates_vec"] = make_small_vec(seed, vec_dim)

                pipe.execute_command("JSON.SET", doc_key, "$", json.dumps(doc_obj))
                count_loaded += 1
        pipe.execute()

    print(f"[setup] inserted {count_loaded} JSON docs under '{key_prefix}*'")

def create_json_index():
    """
    Create a single FT index ON JSON over the keys, including:
      - year (NUMERIC), category (TAG), motivation/firstname/surname (TEXT)
      - laureates (VECTOR) sourced from $.laureates_vec
    """
    indexn = "nobeljson_idx_main"

    # Drop old index if present (data is preserved)
    try:
        rcli.execute_command("FT.DROPINDEX", indexn)
        print("[setup] dropped old JSON index")
    except Exception:
        pass

    # Create index with vector field ON JSON
    rcli.execute_command(
        "FT.CREATE", indexn,
        "ON", "JSON",
        "PREFIX", "1", key_prefix,
        "SCHEMA",
        "$.year",       "AS", "year",       "NUMERIC",
        "$.category",   "AS", "category",   "TAG",
        "$.motivation", "AS", "motivation", "TEXT",
        "$.firstname",  "AS", "firstname",  "TEXT",
        "$.surname",    "AS", "surname",    "TEXT",
        vec_path,       "AS", vec_alias,    "VECTOR", "FLAT", "6",
            "TYPE", "FLOAT32",
            "DIM",  str(vec_dim),
            "DISTANCE_METRIC", "L2"
    )
    print(f"[setup] created JSON index '{indexn}' with VECTOR field '{vec_alias}' "
          f"from path '{vec_path}' (dim={vec_dim})")

if __name__ == "__main__":
    load_docs_json()
    create_json_index()
