# app/plot_boxplots.py
# Reads timing CSVs and saves clean box plots for the report.

import os
import pandas as pd
import matplotlib.pyplot as plt

# Input/output locations (adjust only if your folders differ)
data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
out_dir  = os.path.join(os.path.dirname(os.path.dirname(__file__)), "report", "boxplots")

# Ensure output directory exists
os.makedirs(out_dir, exist_ok=True)

# CSV filenames produced by grpc_client_bench.py
files_map = {
    "CountByCategoryAndYears": "bench_count_category_years.csv",
    "CountByMotivationKeyword": "bench_count_keyword.csv",
    "LookupLaureate": "bench_lookup_name.csv",
}

# Helper to load a CSV and return the latency series (in ms)
def load_latency_series(csv_path: str) -> pd.Series:
    df = pd.read_csv(csv_path)
    # Expect columns: iteration, latency_ms
    if "latency_ms" not in df.columns:
        raise ValueError(f"CSV missing 'latency_ms' column: {csv_path}")
    return df["latency_ms"]

# Plot a single box plot and save it
def save_box(label_txt: str, values: pd.Series, out_path: str) -> None:
    plt.figure(figsize=(6, 6))
    # Single box per chart for clarity in the report
    plt.boxplot(values, vert=True, showmeans=True)
    plt.title(f"{label_txt} – Latency (ms)")
    plt.ylabel("Latency (ms)")
    plt.xlabel("")  # no x label; single-series chart
    plt.grid(True, axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()

def main():
    for label_txt, fname in files_map.items():
        csv_path = os.path.join(data_dir, fname)
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"Could not find CSV: {csv_path}. Run grpc_client_bench.py first.")
        lat_series = load_latency_series(csv_path)
        out_path = os.path.join(out_dir, f"{label_txt}_boxplot.png")
        save_box(label_txt, lat_series, out_path)
        print(f"[plot] saved: {out_path}")

if __name__ == "__main__":
    main()
