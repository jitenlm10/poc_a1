# app/grpc_client_bench.py
import time, csv, statistics
from pathlib import Path
import grpc
import nobel_pb2 as pb
import nobel_pb2_grpc as pbg

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

def bench(fn_call, iterations=100):
    t = []
    for _ in range(iterations):
        t0 = time.perf_counter(); fn_call(); t1 = time.perf_counter()
        t.append((t1 - t0) * 1000.0)
    return t

def write_csv(path, nums):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["iteration", "latency_ms"])
        for i, v in enumerate(nums, 1): w.writerow([i, f"{v:.3f}"])

def print_stats(lbl, nums):
    p50 = statistics.median(nums)
    p90 = statistics.quantiles(nums, n=10)[8] if len(nums) >= 10 else max(nums)
    print(f"{lbl}: min={min(nums):.3f} ms  p50={p50:.3f} ms  p90={p90:.3f} ms  max={max(nums):.3f} ms")

def main(target="localhost:50051"):
    chan = grpc.insecure_channel(target); stub = pbg.NobelQueryStub(chan)
    print("physics 2013–2020 count:", stub.CountByCategoryAndYears(pb.CountRequest(category="physics", year_start=2013, year_end=2020)).total)
    print("'quantum' motivation count:", stub.CountByMotivationKeyword(pb.KeywordRequest(keyword="quantum")).total)
    r3 = stub.LookupLaureate(pb.LookupRequest(first_name="Peter", last_name="Higgs"))
    preview = (r3.motivation[:80] + "...") if len(r3.motivation) > 80 else r3.motivation
    print("lookup (Peter Higgs):", {"year": r3.year, "category": r3.category, "motivation": preview})

    t_cat = bench(lambda: stub.CountByCategoryAndYears(pb.CountRequest(category="physics", year_start=2013, year_end=2020)))
    t_kw = bench(lambda: stub.CountByMotivationKeyword(pb.KeywordRequest(keyword="quantum")))
    t_lookup = bench(lambda: stub.LookupLaureate(pb.LookupRequest(first_name="Peter", last_name="Higgs")))

    write_csv(DATA_DIR / "bench_count_category_years.csv", t_cat)
    write_csv(DATA_DIR / "bench_count_keyword.csv", t_kw)
    write_csv(DATA_DIR / "bench_lookup_name.csv", t_lookup)

    print_stats("CountByCategoryAndYears", t_cat)
    print_stats("CountByMotivationKeyword", t_kw)
    print_stats("LookupLaureate", t_lookup)
    print(f"[bench] CSVs written to: {DATA_DIR}")

if __name__ == "__main__":
    main()
