# grpc_service.py
# gRPC server that implements the three RPCs and queries Redis RediSearch ON JSON.
import os
import grpc
from concurrent import futures
# from redis import Redis
import nobel_pb2, nobel_pb2_grpc
from test_redis import rcli


indexn = "nobeljson_idx_main"

class NobelQueryServicer(nobel_pb2_grpc.NobelQueryServicer):
    def CountByCategoryAndYears(self, request, context):
        # Build FT.SEARCH query:
        #   @category:{physics} @year:[2013 2020]
        qry = f"@category:{{{request.category}}} @year:[{request.year_start} {request.year_end}]"
        box = rcli.execute_command("FT.SEARCH", indexn, qry, "NOCONTENT")
        total = int(box[0]) if box else 0
        return nobel_pb2.CountReply(total=total)

    def CountByMotivationKeyword(self, request, context):
        # Build FT.SEARCH query:
        #   @motivation:quantum
        qry = f"@motivation:{request.keyword}"
        box = rcli.execute_command("FT.SEARCH", indexn, qry, "NOCONTENT")
        total = int(box[0]) if box else 0
        return nobel_pb2.CountReply(total=total)

    def LookupLaureate(self, request, context):
        # Build FT.SEARCH query and return only the aliased fields from schema
        qry = f'@firstname:"{request.first_name}" @surname:"{request.last_name}"'
        box = rcli.execute_command(
            "FT.SEARCH", indexn, qry,
            "RETURN", "3", "year", "category", "motivation",
            "LIMIT", "0", "1"
        )
        if not box or box[0] == 0:
            return nobel_pb2.LookupReply(year="", category="", motivation="")
        fields = dict(zip(box[2][::2], box[2][1::2]))
        return nobel_pb2.LookupReply(
            year=str(fields.get("year", "")),
            category=fields.get("category", ""),
            motivation=fields.get("motivation", "")
        )

# def serve():
#     server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
#     nobel_pb2_grpc.add_NobelQueryServicer_to_server(NobelQueryServicer(), server)
#     server.add_insecure_port("[::]:50051")  # local dev; secure channel when deploying
#     server.start()
#     print("gRPC server listening on :50051")
#     server.wait_for_termination()

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
    nobel_pb2_grpc.add_NobelQueryServicer_to_server(NobelQueryServicer(), server)
    port = os.environ.get("PORT", "8080")          # <— Cloud Run contract
    server.add_insecure_port(f"[::]:{port}")
    server.start()
    print(f"gRPC server listening on :{port}")
    server.wait_for_termination()

if __name__ == "__main__":
    serve()
