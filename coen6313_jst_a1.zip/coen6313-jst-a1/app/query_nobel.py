# query_nobel.py
# from redis import Redis
from test_redis import rcli


indexn = "nobeljson_idx_main"

def count_by_category_and_years(cat_tok: str, yr_a: int, yr_b: int) -> int:
    lo, hi = sorted([yr_a, yr_b])
    lo = max(2013, lo); hi = min(2023, hi)
    qry = f"@category:{{{cat_tok}}} @year:[{lo} {hi}]"
    box = rcli.execute_command("FT.SEARCH", indexn, qry, "NOCONTENT")
    return box[0] if box else 0

def count_by_keyword_in_motivation(term_tok: str) -> int:
    qry = f"@motivation:{term_tok}"
    box = rcli.execute_command("FT.SEARCH", indexn, qry, "NOCONTENT")
    return box[0] if box else 0

def lookup_laureate(first_tok: str, last_tok: str):
    qry = f'@firstname:"{first_tok}" @surname:"{last_tok}"'
    box = rcli.execute_command("FT.SEARCH", indexn, qry, "RETURN", "3", "year", "category", "motivation", "LIMIT", "0", "5")
    if not box or box[0] == 0:
        return None
    fields = dict(zip(box[2][::2], box[2][1::2]))
    return {"year": fields.get("year", ""), "category": fields.get("category", ""), "motivation": fields.get("motivation", "")}

if __name__ == "__main__":
    print("physics 2013–2020 count:", count_by_category_and_years("physics", 2013, 2020))
    print("'quantum' motivation count:", count_by_keyword_in_motivation("quantum"))
    print("lookup (Peter Higgs):", lookup_laureate("Peter", "Higgs"))
