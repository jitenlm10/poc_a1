"""Basic connection example.
"""

from redis import Redis

rcli = Redis(
    host='redis-12106.crce174.ca-central-1-1.ec2.redns.redis-cloud.com',
    port=12106,
    decode_responses=True,
    username="jitendra",
    password="User_role_1",
)

# success = r.set('foo', 'bar')
# # True

# result = r.get('foo')
# print(result)
# # >>> bar

